<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parlay 4D Admin Login</title>
    <link rel="stylesheet" type="text/css" href="../admin/css/login.css">
    <link rel="icon" type="image/x-icon" href="../assets/images/favicon.png">
</head>
<body>
    
    <div class="pen-title">
        
    </div>
    <div class="rerun"><a href="#"><img src="assets/images/logo.png" width="200" height="40"></a></div>
        <div class="container">
        <div class="card"></div>
            <div class="card">
                <h1 class="title">Login</h1>
                <div class="error"><?php
                if(isset($_GET['error'])){
                    echo $_GET[error];
                    
                }
                ?></div>
                                
                <form action="./admin/assets/loginVerify.php" method="POST">
                    <div class="input-container">
                        <input type="text" id="#{label}" name="username" required="required"/>
                        <label for="#{label}">Username</label>
                        <div class="bar"></div>
                    </div>
                    <div class="input-container">
                        <input type="password" id="#{label}"  name="passcode" required="required"/>
                        <label for="#{label}">Password</label>
                        <div class="bar"></div>
                    </div>
                    <div class="button-container">
                        <button type="submit" name="submit"><span>Go</span></button>
                    </div>
                    <div class="forget"><a href="./admin/assets/forgot.php">Forgot your password?</a></div>
                </form>
            </div>
        </div>
    </div>

</body>
</html>