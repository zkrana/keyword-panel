<?php
include 'session.php';

// Establish a database connection (Replace with your database credentials)
$host_source='localhost';
$host_user='lewat88_adPKey';
$user_passcode='aF_z;KhqHc]~';
$db_name='lewat88_adKey';

$connect = mysqli_connect($host_source,$host_user,$user_passcode,$db_name);

// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id = mysqli_real_escape_string($connect, $_GET['id']);

    // Create an SQL query to delete the record with the given ID
    $sql = "DELETE FROM keywords WHERE id = $id";

    if (mysqli_query($connect, $sql)) {
        // Data deleted successfully, you can redirect to another page or display a success message
        header("Location: dashboard.php"); // Redirect to a success page
        exit;
    } else {
        // Display an error message
        echo "Error: " . mysqli_error($connect);
    }
}

// Close the database connection
mysqli_close($connect);
?>
