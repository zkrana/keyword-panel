<?php

$host_source='localhost';
$host_user='lewat88_adPKey';
$user_passcode='aF_z;KhqHc]~';
$db_name='lewat88_adKey';

$connect = mysqli_connect($host_source,$host_user,$user_passcode,$db_name);

// Check connection
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
  }
?>
