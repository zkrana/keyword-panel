<?php
// Establish a database connection (You should replace these values with your own)
$host_source='localhost';
$host_user='lewat88_adPKey';
$user_passcode='aF_z;KhqHc]~';
$db_name='lewat88_adKey';

$connect = mysqli_connect($host_source,$host_user,$user_passcode,$db_name);

// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

error_reporting(E_ALL);
ini_set('display_errors', 1);


$error_message = '';
$success_message = '';

// Get the user's email from the form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_email = $_POST['email'];

    // Check if the email exists in the database
    $check_email_sql = "SELECT * FROM user_table WHERE user_email = '$user_email'";
    $result = mysqli_query($connect, $check_email_sql);

    if (mysqli_num_rows($result) > 0) {
        // Generate a unique token
        $token = bin2hex(openssl_random_pseudo_bytes(16));

        // Store the token and expiration time in the database
        $reset_expiration = date('Y-m-d H:i:s', strtotime('+1 hour'));
        $sql = "UPDATE user_table SET reset_token = '$token', reset_expiration = '$reset_expiration' WHERE user_email = '$user_email'";
        if (mysqli_query($connect, $sql)) {
            // Send a password reset link to the user's email
            $reset_link = "https://panel.lewat88.com/admin/assets/reset_password.php?token=$token";
            // You can send an email containing the $reset_link to the user here

            $success_message = "A password reset link has been sent to your email. " ." </br> "." Please check your inbox.";

            // Include the message in the URL parameter when redirecting
            header("Location: forgot.php?success_message=$success_message");
            exit; // Make sure to exit after the header redirection
        } else {
            $error_message = "Error: " . mysqli_error($connect);
        }
    } else {
        $error_message = "The email doesn't exist in our database. " ." </br> "." Please check your email address.";
        header("Location: forgot.php?error_message=$error_message");
    }

    // Close the database connection
    mysqli_close($connect);
}

?>
