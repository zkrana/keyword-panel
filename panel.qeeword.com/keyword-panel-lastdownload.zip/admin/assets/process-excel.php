<?php
require 'vendor/autoload.php'; // Include the PhpSpreadsheet library

// Database configuration
$host = 'your_database_host';
$username = 'your_database_username';
$password = 'your_database_password';
$database = 'your_database_name';

try {
    // Connect to the database
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if a file was uploaded
    if (isset($_FILES['excel_file']) && $_FILES['excel_file']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['excel_file']['tmp_name'];

        // Load the Excel file
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($fileTmpPath);
        $worksheet = $spreadsheet->getActiveSheet();

        // Iterate through the rows to extract keyword name and URL
        foreach ($worksheet->getRowIterator() as $row) {
            $cellIterator = $row->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(FALSE);
            
            $rowData = [];
            foreach ($cellIterator as $cell) {
                $rowData[] = $cell->getValue();
            }
            
            if (count($rowData) >= 2) {
                $keywordName = $rowData[0];
                $keywordUrl = $rowData[1];

                // Insert data into the database
                $insertQuery = "INSERT INTO keyword_table (keyword_name, keyword_url) VALUES (:keyword_name, :keyword_url)";
                $stmt = $pdo->prepare($insertQuery);
                $stmt->bindParam(':keyword_name', $keywordName);
                $stmt->bindParam(':keyword_url', $keywordUrl);
                $stmt->execute();
            }
        }

        echo "Data from Excel file inserted into the database successfully.";
    } else {
        echo "No file uploaded or an error occurred.";
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
