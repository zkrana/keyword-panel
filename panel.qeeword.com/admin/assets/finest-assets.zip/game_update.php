


<?php

require_once 'session.php';


$host_source='localhost';
$host_user='root';
$user_passcode='';
$db_name='parlayadmin';

// $host_source='localhost';
// $host_user='root';
// $user_passcode='';
// $db_name='testdata';


$connect = mysqli_connect($host_source,$host_user,$user_passcode,$db_name);

// Check connection
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}



if(isset($_POST['Update']))
{

    $up_id = $_POST['updating'];
    $data = "SELECT * FROM game_item WHERE id = $up_id";
    $query = mysqli_query($connect, $data);
    $count = mysqli_num_rows($query);
    if( $count > 0){
        while($countData = mysqli_fetch_assoc($query)){
            $oldImage = $countData['game_image'];
        }
    }

    $gameName = mysqli_real_escape_string($connect, $_POST['game_update_name']);
    $percent = mysqli_real_escape_string($connect, $_POST['win_update_rate']);
    $file_name = $_FILES['game_update_files']['name'];
    $tmp_name = $_FILES['game_update_files']['tmp_name'];
    unlink('../assets/img/uploads/game_photo/'.$oldImage);
    // get the image extension
    $extension = substr($file_name,strlen($file_name)-4,strlen($file_name));
    // allowed extensions
    $allowed_extensions = array(".jpg","jpeg",".png",".gif",".webp");
    // Validation for allowed extensions .in_array() function searches an array for a specific value.
    if(!in_array($extension,$allowed_extensions))
    {
        echo "<script>alert('Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
    } else{

        // Code for move image into directory
        move_uploaded_file($tmp_name,"../assets/img/uploads/game_photo/".basename($file_name));

            $sql = "UPDATE `game_item` SET game_image = '$file_name', game_name = '$gameName', percent = '$percent' WHERE id='$up_id'";

            if (mysqli_query($connect, $sql)) {

                
                echo "<script>alert('You have successfully updated the data');</script>";
                echo "<script type='text/javascript'> document.location ='../assets/rtp_all_game.php'; </script>";

            } else {
                echo "<script>alert('Something Went Wrong. Please try again');</script>";
                echo "<script type='text/javascript'> document.location ='../assets/rtp_all_game.php'; </script>";
        }
     }
}


?>