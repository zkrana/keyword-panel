<?php
include ("config.php");
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = mysqli_real_escape_string($connect, trim($_POST['date']));
    $hari_name = mysqli_real_escape_string($connect, trim($_POST['hari_name']));
    $hk_number = mysqli_real_escape_string($connect, trim($_POST['hk_number']));
    $sgp_number = mysqli_real_escape_string($connect, trim($_POST['sgp_number']));

    
    if(!empty($date) && !empty($hari_name) && !empty($hk_number) && !empty($sgp_number)){
        
         $b_status = "INSERT INTO hk_sgp (`tanggal`,`hari`,`hk`,`sgp`) VALUES ('$date','$hari_name','$hk_number','$sgp_number')";

        $sql_inst = mysqli_query($connect, $b_status);
        if($sql_inst){
            header("Location: tabledata.php");
        }else{
            echo "Data Insert Failed.";
        }
    }
}



?>