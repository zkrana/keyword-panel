<?php

error_reporting(error_reporting() & ~E_NOTICE);


include "config.php";
$errors=array();

if($_SERVER["REQUEST_METHOD"] == "POST") {
    // username and password sent from form

    $myusername = mysqli_real_escape_string($connect,$_POST['username']);
    $password = stripslashes($_POST['password']);
    $myuserpass = mysqli_real_escape_string($connect,$_POST['passcode']);
    $passcode = md5($myuserpass);
    
    
    //echo "Input Pass md5 = ".$password."</br>";
    $sql = "SELECT * FROM user_table WHERE username = '$myusername' OR user_email = '$myusername' AND password = '$passcode' AND status='active'";
    $result = mysqli_query($connect,$sql);
    $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
        $user_id = $row['id'];
    $user=$row['username'];
    $mail=$row['user_email'];
    $pass = $row['password'];
    $user_status=$row['status'];
    
    
  

   

    $count = mysqli_num_rows($result);

    // If result matched $myusername and $mypassword, table row must be 1 row

    if($myusername==$user || $myusername==$mail) {
            if($passcode==$pass){
                if($user_status=='active'){
                    session_start();
                    $_SESSION['id'] = $user_id;
                    $_SESSION['status']=$user_status;
                    $_SESSION['loggedin_time'] = time();
                    header("location: dashboard.php");
                }else{
                    $errors="Your account is now inactive by admin. Please contact with admin.";
                    header("Location: ../index.php?error='$errors'");
                }
            }else{
                $errors="Password not matched.";
                header("Location: ../index.php?error='$errors'");
            }
    }else {
        $errors="Username Not Matched.";
        header("Location: ../index.php?error='$errors'");
        //  $error = "Your Login Name or Password is invalid";
    }
}
?>