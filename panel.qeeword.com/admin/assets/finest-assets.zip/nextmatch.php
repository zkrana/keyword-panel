<?php

$host_source='localhost';
$host_user='root';
$user_passcode='';
$db_name='parlayadmin';

$connect = mysqli_connect($host_source,$host_user,$user_passcode,$db_name);

// Check connection
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
  }

    if(isset($_POST['submit'])){
        $liga_name = $_POST['liga_name'];
        $team_a = $_POST['team_a'];
        $team_b = $_POST['team_b'];
        $match_date = $_POST['date'];
        $match_time = $_POST['time'];

        foreach($team_a as $key => $value)
          {
            $team_1 = $value;
            $liga_n = $liga_name[$key];
            $team_2 = $team_b[$key];
            $ins_date = $match_date[$key];
            $ins_time = $match_time[$key];
            $up_match_data = "INSERT INTO upcoming_match (liga_name,team1,team2,date,time) 
            VALUES ('$liga_n','$team_1','$team_2','$ins_date','$ins_time')";
            if(mysqli_query($connect,$up_match_data)){
                header("Location: upcomingmatch.php");
            }
        }

    }

?>