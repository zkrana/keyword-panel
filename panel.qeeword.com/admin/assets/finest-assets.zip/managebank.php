<?php include("session.php"); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Parlay Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="This is an example dashboard created using build-in elements and components.">
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="icon" type="image/x-icon" href="../../assets/images/favicon.png">
    <link href="https://demo.dashboardpack.com/architectui-html-free/main.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="../css/style2.css" rel="stylesheet"/>
</head>
<body>
<div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
    <div class="app-header header-shadow">
        <div class="app-header__logo">
            <div class="logo-src">
                <a href="dashboard.php"><img src="../assets/img/logo.png" width="200" height="40"></a>
            </div>
            <div class="header__pane ml-auto">
                <div>
                    <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                    </button>
                </div>
            </div>
        </div>
        <div class="app-header__mobile-menu">
            <div>
                <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                </button>
            </div>
        </div>
        <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
        </div>    <div class="app-header__content">
            <div class="app-header-left">
                <div class="search-wrapper">
                    <div class="input-holder">
                        <input type="text" class="search-input" placeholder="Type to search">
                        <button class="search-icon"><span></span></button>
                    </div>
                    <button class="close"></button>
                </div>
                <ul class="header-menu nav">
                    <li class="nav-item">
                        <a href="manageuser.php" class="nav-link">
                            <i class="nav-link-icon fas fa-users"></i>
                            Users
                        </a>
                    </li>
                    <li class="btn-group nav-item">
                        <a href="manageuser.php" class="nav-link">
                            <i class="nav-link-icon fas fa-edit"></i>
                            Edit
                        </a>
                    </li>
                    <li class="dropdown nav-item">
                        <a href="javascript:void(0);" class="nav-link">
                            <i class="nav-link-icon fa fa-cog"></i>
                            Settings
                        </a>
                    </li>
                </ul>        </div>
            <div class="app-header-right">
                <div class="header-btn-lg pr-0">
                    <div class="widget-content p-0">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="btn-group">
                                    <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="p-0 btn">
                                        <img width="42" class="rounded-circle" src="assets/images/avatars/1.jpg" alt="">
                                        <i class="fa fa-angle-down ml-2 opacity-8"></i>
                                    </a>
                                    <div tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu dropdown-menu-right">
                                        <button type="button" tabindex="0" class="dropdown-item"><a href="useraccount.php">Profile</a></button>
                                        <button type="button" tabindex="0" class="dropdown-item"><a href="logout.php">Logout</a></button>
                                        <!-- <h6 tabindex="-1" class="dropdown-header">Header</h6>
                                        <button type="button" tabindex="0" class="dropdown-item">Actions</button>
                                        <div tabindex="-1" class="dropdown-divider"></div>
                                        <button type="button" tabindex="0" class="dropdown-item">Dividers</button> -->
                                    </div>
                                </div>
                            </div>
                            <div class="widget-content-left  ml-3 header-user-info">
                                <div class="widget-heading">
                                    <?php echo $login_session; ?>
                                </div>
                                <div class="widget-subheading">
                                    Parlay  <?php echo ucfirst($login_role); ?>
                                </div>
                            </div>
                            <div class="widget-content-right header-user-info ml-3">
                                <span class="prfil-img"><img width="40" height="40" src="img/uploads/user_photo/<?php echo $user_photo; ?>" alt=""> </span> 
                                      
                                </div>
                        </div>
                    </div>
                </div>        </div>
        </div>
    </div>        <div class="ui-theme-settings">
        <button type="button" id="TooltipDemo" class="btn-open-options btn btn-warning">
            <i class="fa fa-cog fa-w-16 fa-spin fa-2x"></i>
        </button>
        <div class="theme-settings__inner">
            <div class="scrollbar-container">
                <div class="theme-settings__options-wrapper">
                    <h3 class="themeoptions-heading">Layout Options
                    </h3>
                    <div class="p-3">
                        <ul class="list-group">
                            <li class="list-group-item">
                                <div class="widget-content p-0">
                                    <div class="widget-content-wrapper">
                                        <div class="widget-content-left mr-3">
                                            <div class="switch has-switch switch-container-class" data-class="fixed-header">
                                                <div class="switch-animate switch-on">
                                                    <input type="checkbox" checked data-toggle="toggle" data-onstyle="success">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Fixed Header
                                            </div>
                                            <div class="widget-subheading">Makes the header top fixed, always visible!
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="list-group-item">
                                <div class="widget-content p-0">
                                    <div class="widget-content-wrapper">
                                        <div class="widget-content-left mr-3">
                                            <div class="switch has-switch switch-container-class" data-class="fixed-sidebar">
                                                <div class="switch-animate switch-on">
                                                    <input type="checkbox" checked data-toggle="toggle" data-onstyle="success">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Fixed Sidebar
                                            </div>
                                            <div class="widget-subheading">Makes the sidebar left fixed, always visible!
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="list-group-item">
                                <div class="widget-content p-0">
                                    <div class="widget-content-wrapper">
                                        <div class="widget-content-left mr-3">
                                            <div class="switch has-switch switch-container-class" data-class="fixed-footer">
                                                <div class="switch-animate switch-off">
                                                    <input type="checkbox" data-toggle="toggle" data-onstyle="success">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Fixed Footer
                                            </div>
                                            <div class="widget-subheading">Makes the app footer bottom fixed, always visible!
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <h3 class="themeoptions-heading">
                        <div>
                            Header Options
                        </div>
                        <button type="button" class="btn-pill btn-shadow btn-wide ml-auto btn btn-focus btn-sm switch-header-cs-class" data-class="">
                            Restore Default
                        </button>
                    </h3>
                    <div class="p-3">
                        <ul class="list-group">
                            <li class="list-group-item">
                                <h5 class="pb-2">Choose Color Scheme
                                </h5>
                                <div class="theme-settings-swatches">
                                    <div class="swatch-holder bg-primary switch-header-cs-class" data-class="bg-primary header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-secondary switch-header-cs-class" data-class="bg-secondary header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-success switch-header-cs-class" data-class="bg-success header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-info switch-header-cs-class" data-class="bg-info header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-warning switch-header-cs-class" data-class="bg-warning header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-danger switch-header-cs-class" data-class="bg-danger header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-light switch-header-cs-class" data-class="bg-light header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-dark switch-header-cs-class" data-class="bg-dark header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-focus switch-header-cs-class" data-class="bg-focus header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-alternate switch-header-cs-class" data-class="bg-alternate header-text-light">
                                    </div>
                                    <div class="divider">
                                    </div>
                                    <div class="swatch-holder bg-vicious-stance switch-header-cs-class" data-class="bg-vicious-stance header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-midnight-bloom switch-header-cs-class" data-class="bg-midnight-bloom header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-night-sky switch-header-cs-class" data-class="bg-night-sky header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-slick-carbon switch-header-cs-class" data-class="bg-slick-carbon header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-asteroid switch-header-cs-class" data-class="bg-asteroid header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-royal switch-header-cs-class" data-class="bg-royal header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-warm-flame switch-header-cs-class" data-class="bg-warm-flame header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-night-fade switch-header-cs-class" data-class="bg-night-fade header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-sunny-morning switch-header-cs-class" data-class="bg-sunny-morning header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-tempting-azure switch-header-cs-class" data-class="bg-tempting-azure header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-amy-crisp switch-header-cs-class" data-class="bg-amy-crisp header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-heavy-rain switch-header-cs-class" data-class="bg-heavy-rain header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-mean-fruit switch-header-cs-class" data-class="bg-mean-fruit header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-malibu-beach switch-header-cs-class" data-class="bg-malibu-beach header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-deep-blue switch-header-cs-class" data-class="bg-deep-blue header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-ripe-malin switch-header-cs-class" data-class="bg-ripe-malin header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-arielle-smile switch-header-cs-class" data-class="bg-arielle-smile header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-plum-plate switch-header-cs-class" data-class="bg-plum-plate header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-happy-fisher switch-header-cs-class" data-class="bg-happy-fisher header-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-happy-itmeo switch-header-cs-class" data-class="bg-happy-itmeo header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-mixed-hopes switch-header-cs-class" data-class="bg-mixed-hopes header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-strong-bliss switch-header-cs-class" data-class="bg-strong-bliss header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-grow-early switch-header-cs-class" data-class="bg-grow-early header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-love-kiss switch-header-cs-class" data-class="bg-love-kiss header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-premium-dark switch-header-cs-class" data-class="bg-premium-dark header-text-light">
                                    </div>
                                    <div class="swatch-holder bg-happy-green switch-header-cs-class" data-class="bg-happy-green header-text-light">
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <h3 class="themeoptions-heading">
                        <div>Sidebar Options</div>
                        <button type="button" class="btn-pill btn-shadow btn-wide ml-auto btn btn-focus btn-sm switch-sidebar-cs-class" data-class="">
                            Restore Default
                        </button>
                    </h3>
                    <div class="p-3">
                        <ul class="list-group">
                            <li class="list-group-item">
                                <h5 class="pb-2">Choose Color Scheme
                                </h5>
                                <div class="theme-settings-swatches">
                                    <div class="swatch-holder bg-primary switch-sidebar-cs-class" data-class="bg-primary sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-secondary switch-sidebar-cs-class" data-class="bg-secondary sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-success switch-sidebar-cs-class" data-class="bg-success sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-info switch-sidebar-cs-class" data-class="bg-info sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-warning switch-sidebar-cs-class" data-class="bg-warning sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-danger switch-sidebar-cs-class" data-class="bg-danger sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-light switch-sidebar-cs-class" data-class="bg-light sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-dark switch-sidebar-cs-class" data-class="bg-dark sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-focus switch-sidebar-cs-class" data-class="bg-focus sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-alternate switch-sidebar-cs-class" data-class="bg-alternate sidebar-text-light">
                                    </div>
                                    <div class="divider">
                                    </div>
                                    <div class="swatch-holder bg-vicious-stance switch-sidebar-cs-class" data-class="bg-vicious-stance sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-midnight-bloom switch-sidebar-cs-class" data-class="bg-midnight-bloom sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-night-sky switch-sidebar-cs-class" data-class="bg-night-sky sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-slick-carbon switch-sidebar-cs-class" data-class="bg-slick-carbon sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-asteroid switch-sidebar-cs-class" data-class="bg-asteroid sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-royal switch-sidebar-cs-class" data-class="bg-royal sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-warm-flame switch-sidebar-cs-class" data-class="bg-warm-flame sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-night-fade switch-sidebar-cs-class" data-class="bg-night-fade sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-sunny-morning switch-sidebar-cs-class" data-class="bg-sunny-morning sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-tempting-azure switch-sidebar-cs-class" data-class="bg-tempting-azure sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-amy-crisp switch-sidebar-cs-class" data-class="bg-amy-crisp sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-heavy-rain switch-sidebar-cs-class" data-class="bg-heavy-rain sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-mean-fruit switch-sidebar-cs-class" data-class="bg-mean-fruit sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-malibu-beach switch-sidebar-cs-class" data-class="bg-malibu-beach sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-deep-blue switch-sidebar-cs-class" data-class="bg-deep-blue sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-ripe-malin switch-sidebar-cs-class" data-class="bg-ripe-malin sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-arielle-smile switch-sidebar-cs-class" data-class="bg-arielle-smile sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-plum-plate switch-sidebar-cs-class" data-class="bg-plum-plate sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-happy-fisher switch-sidebar-cs-class" data-class="bg-happy-fisher sidebar-text-dark">
                                    </div>
                                    <div class="swatch-holder bg-happy-itmeo switch-sidebar-cs-class" data-class="bg-happy-itmeo sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-mixed-hopes switch-sidebar-cs-class" data-class="bg-mixed-hopes sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-strong-bliss switch-sidebar-cs-class" data-class="bg-strong-bliss sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-grow-early switch-sidebar-cs-class" data-class="bg-grow-early sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-love-kiss switch-sidebar-cs-class" data-class="bg-love-kiss sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-premium-dark switch-sidebar-cs-class" data-class="bg-premium-dark sidebar-text-light">
                                    </div>
                                    <div class="swatch-holder bg-happy-green switch-sidebar-cs-class" data-class="bg-happy-green sidebar-text-light">
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <h3 class="themeoptions-heading">
                        <div>Main Content Options</div>
                        <button type="button" class="btn-pill btn-shadow btn-wide ml-auto active btn btn-focus btn-sm">Restore Default
                        </button>
                    </h3>
                    <div class="p-3">
                        <ul class="list-group">
                            <li class="list-group-item">
                                <h5 class="pb-2">Page Section Tabs
                                </h5>
                                <div class="theme-settings-swatches">
                                    <div role="group" class="mt-2 btn-group">
                                        <button type="button" class="btn-wide btn-shadow btn-primary btn btn-secondary switch-theme-class" data-class="body-tabs-line">
                                            Line
                                        </button>
                                        <button type="button" class="btn-wide btn-shadow btn-primary active btn btn-secondary switch-theme-class" data-class="body-tabs-shadow">
                                            Shadow
                                        </button>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="app-main">
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                                    <span class="hamburger-box">
                                        <span class="hamburger-inner"></span>
                                    </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                        <span>
                            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                                <span class="btn-icon-wrapper">
                                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                                </span>
                            </button>
                        </span>
            </div>    <div class="scrollbar-sidebar">
                <div class="app-sidebar__inner">
                    <ul class="vertical-nav-menu">
                        <li class="app-sidebar__heading">Navigation Link</li>
                        <li>
                            <a href="bigmatch.php">
                            <i class="fa-solid fa-calendar-days metismenu-icon pe-7s-display2"></i>
                                Big Match Schedule
                            </a>
                        </li>
                        <li class="app-sidebar__heading">Manage Data</li>
                        <!-- <li>
                            <a href="#">
                                <i class="metismenu-icon pe-7s-diamond"></i>
                                Elements
                                <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                            </a>
                            <ul>
                                <li>
                                    <a href="elements-buttons-standard.html">
                                        <i class="metismenu-icon"></i>
                                        Manage
                                    </a>
                                </li>
                                <li>
                                    <a href="elements-dropdowns.html">
                                        <i class="metismenu-icon">
                                        </i>Dropdowns
                                    </a>
                                </li>
                                <li>
                                    <a href="elements-icons.html">
                                        <i class="metismenu-icon">
                                        </i>Icons
                                    </a>
                                </li>
                                <li>
                                    <a href="elements-badges-labels.html">
                                        <i class="metismenu-icon">
                                        </i>Badges
                                    </a>
                                </li>
                                <li>
                                    <a href="elements-cards.html">
                                        <i class="metismenu-icon">
                                        </i>Cards
                                    </a>
                                </li>
                                <li>
                                    <a href="elements-list-group.html">
                                        <i class="metismenu-icon">
                                        </i>List Groups
                                    </a>
                                </li>
                                <li>
                                    <a href="elements-navigation.html">
                                        <i class="metismenu-icon">
                                        </i>Navigation Menus
                                    </a>
                                </li>
                                <li>
                                    <a href="elements-utilities.html">
                                        <i class="metismenu-icon">
                                        </i>Utilities
                                    </a>
                                </li>
                            </ul>
                        </li> -->
                        <li>
                                    <a href="managebank.php">
                                        <i class="fa-solid fa-building-columns metismenu-icon pe-7s-cash"></i>
                                        Manage Bank 
                                    </a>
                                    
                                </li>
                                <li  >
                                    <a href="manageuser.php">
                                        <i class="fa-solid fa-user metismenu-icon pe-7s-user"></i>
                                        Manage Users
                                    </a>
                                </li>
                                <li class="app-sidebar__heading">Upcoming Match</li>
                                <li>
                                    <a href="upcomingmatch.php">
                                        <i class="fa-solid fa-calendar metismenu-icon pe-7s-display2"></i>
                                        Upcoming Match Schedule
                                    </a>
                                </li>
                                <li class="app-sidebar__heading">RTP Game Add</li>
                                <li>
                                    <a href="rtp_all_game.php">
                                        <i class="fa-solid fa-puzzle-piece metismenu-icon pe-7s-display2"></i>
                                        All RTP Game
                                    </a>
                                </li>
                                <li>
                                    <a href="addgame.php">
                                        <i class="fa-solid fa-file-circle-plus metismenu-icon pe-7s-display2"></i>
                                        Add Game
                                    </a>
                                </li>
                                
                                <li class="app-sidebar__heading">Togel Table Input</li>
                                <li>
                                    <a href="rtp_all_game.php">
                                        <i class="fa-solid fa-table metismenu-icon pe-7s-display2"></i>
                                        Togel Table
                                    </a>
                                </li>
                                <li>
                                    <a href="tabledata.php">
                                       <i class="fa-solid fa-calendar-plus metismenu-icon pe-7s-display2"></i>
                                        Add Togel Data
                                    </a>
                                </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="app-main__outer">
            <div class="app-main__inner">
                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="fas fa-users-cog" size="9x"></i>
                            </div>
                            <div>Manage Bank Status
                                <div class="page-title-subheading">Welcome to parlay bank status control panel.
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="main-card mb-3 card">
                            <div class="card-header">BANK PANEL
                                <!-- <div class="btn-actions-pane-right">
                                    <div role="group" class="btn-group-sm btn-group">
                                        <button class="active btn btn-focus">Last Week</button>
                                        <button class="btn btn-focus">All Month</button>
                                    </div>
                                </div> -->
                            </div>
                            <div class="table-responsive manage-bank-responsive">
                                <form action="bank_status.php" method="post">
                                    <fieldset>
                                        <table class="table table-striped banktbl">
                                            <thead>
                                            <tr>
                                                <th>Nama Bank</th>
                                                <th>Status Bank</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            $host_source='localhost';
                                            $host_user='root';
                                            $user_passcode='';
                                            $db_name='parlayadmin';

                                            $connect = mysqli_connect($host_source,$host_user,$user_passcode,$db_name);

                                            // Check connection
                                            if ($connect->connect_error) {
                                                die("Connection failed: " . $connect->connect_error);
                                            }
                                                        
                                            $s_bnk_data = "SELECT * FROM bank_status ORDER BY id DESC";
                                            $bca_query  = mysqli_query($connect,$s_bnk_data);
                                            $count_values = mysqli_num_rows($bca_query);
                                            if($count_values>0){
                                            if($bca_fetch = mysqli_fetch_assoc($bca_query)){
                                                        ?>
                                            <tr>
                                                <td>
                                                    BCA
                                                </td>
                                                <td>
                                                    <select name="bca" id="bca" value="<?php echo $bca_fetch['bca']; ?>">
                                                        <?php
                                                                if($bca_fetch['bca'] == 'online'){
                                                                    echo "<option value='online' selected>Online</option>";
                                                                    echo "<option value='offline'>Offline</option>";
                                                                    echo "<option value='gangguan'>Gangguan</option>";

                                                                }elseif($bca_fetch['bca'] == 'offline'){
                                                                    echo "<option value='offline' selected>Offline</option>";
                                                                    echo "<option value='online'>Online</option>";
                                                                    echo "<option value='gangguan'>Gangguan</option>";
                                                                }else{
                                                                    echo "<option value='gangguan' selected>Gangguan</option>";
                                                                    echo "<option value='online'>Online</option>";
                                                                    echo "<option value='offline'>Offline</option>";
                                                                }
                                                                ?>

                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    BNI
                                                </td>
                                                <td>
                                                    <select name="bni" id="bca" value="<?php echo $bca_fetch['bni']; ?>">
                                                        <?php
                                                                if($bca_fetch['bni'] == 'online'){
                                                                    echo "<option value='online' selected>Online</option>";
                                                                    echo "<option value='offline'>Offline</option>";
                                                                    echo "<option value='gangguan'>Gangguan</option>";

                                                                }elseif($bca_fetch['bni'] == 'offline'){
                                                                    echo "<option value='offline' selected>Offline</option>";
                                                                    echo "<option value='online'>Online</option>";
                                                                    echo "<option value='gangguan'>Gangguan</option>";
                                                                }else{
                                                                    echo "<option value='gangguan' selected>Gangguan</option>";
                                                                    echo "<option value='online'>Online</option>";
                                                                    echo "<option value='offline'>Offline</option>";
                                                                }
                                                        ?>

                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    BRI
                                                </td>
                                                <td>
                                                    <select name="bri" id="bca" value="<?php echo $bca_fetch['bri']; ?>">
                                                        <?php
                                                        if($bca_fetch['bri'] == 'online'){
                                                            echo "<option value='online' selected>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";

                                                        }elseif($bca_fetch['bri'] == 'offline'){
                                                            echo "<option value='offline' selected>Offline</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";
                                                        }else{
                                                            echo "<option value='gangguan' selected>Gangguan</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                        }
                                                        ?>

                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    MANDIRI
                                                </td>
                                                <td>
                                                    <select name="mandiri" id="bca" value="<?php echo $bca_fetch['mandiri']; ?>">
                                                        <?php
                                                        if($bca_fetch['mandiri'] == 'online'){
                                                            echo "<option value='online' selected>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";

                                                        }elseif($bca_fetch['mandiri'] == 'offline'){
                                                            echo "<option value='offline' selected>Offline</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";
                                                        }else{
                                                            echo "<option value='gangguan' selected>Gangguan</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                        }

                                                        ?>

                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    DANAMON
                                                </td>
                                                <td>
                                                    <select name="danamon" id="bca" value="<?php echo $bca_fetch['danamon']; ?>">
                                                        <?php
                                                        if($bca_fetch['danamon'] == 'online'){
                                                            echo "<option value='online' selected>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";

                                                        }elseif($bca_fetch['danamon'] == 'offline'){
                                                            echo "<option value='offline' selected>Offline</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";
                                                        }else{
                                                            echo "<option value='gangguan' selected>Gangguan</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                        }
                                                        ?>

                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    CIMB
                                                </td>
                                                <td>
                                                    <select name="cimb" id="bca" value="<?php echo $bca_fetch['cimb']; ?>">
                                                        <?php
                                                        if($bca_fetch['cimb'] == 'online'){
                                                            echo "<option value='online' selected>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";

                                                        }elseif($bca_fetch['cimb'] == 'offline'){
                                                            echo "<option value='offline' selected>Offline</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";
                                                        }else{
                                                            echo "<option value='gangguan' selected>Gangguan</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                        }
                                                        }
                                                        }
                                                        ?>

                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    Gopay
                                                </td>
                                                <td>
                                                    <select name="gopay" id="bca" value="<?php echo $bca_fetch['gopay']; ?>">
                                                        <?php
                                                        if($bca_fetch['gopay'] == 'online'){
                                                            echo "<option value='online' selected>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";

                                                        }elseif($bca_fetch['gopay'] == 'offline'){
                                                            echo "<option value='offline' selected>Offline</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";
                                                        }else{
                                                            echo "<option value='gangguan' selected>Gangguan</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                        }
                                                        ?>

                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    Link Aja
                                                </td>
                                                <td>
                                                    <select name="linkaja" id="bca" value="<?php echo $bca_fetch['linkaja']; ?>">
                                                        <?php
                                                        if($bca_fetch['linkaja'] == 'online'){
                                                            echo "<option value='online' selected>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";

                                                        }elseif($bca_fetch['linkaja'] == 'offline'){
                                                            echo "<option value='offline' selected>Offline</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";
                                                        }else{
                                                            echo "<option value='gangguan' selected>Gangguan</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                        }
                                                        ?>

                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    Ovo
                                                </td>
                                                <td>
                                                    <select name="ovo" id="bca" value="<?php echo $bca_fetch['ovo']; ?>">
                                                        <?php
                                                        if($bca_fetch['ovo'] == 'online'){
                                                            echo "<option value='online' selected>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";

                                                        }elseif($bca_fetch['ovo'] == 'offline'){
                                                            echo "<option value='offline' selected>Offline</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";
                                                        }else{
                                                            echo "<option value='gangguan' selected>Gangguan</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                        }
                                                        ?>

                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    Telkomsel
                                                </td>
                                                <td>
                                                    <select name="telkomsel" id="bca" value="<?php echo $bca_fetch['telkomsel']; ?>">
                                                        <?php
                                                        if($bca_fetch['telkomsel'] == 'online'){
                                                            echo "<option value='online' selected>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";

                                                        }elseif($bca_fetch['telkomsel'] == 'offline'){
                                                            echo "<option value='offline' selected>Offline</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";
                                                        }else{
                                                            echo "<option value='gangguan' selected>Gangguan</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                        }
                                                        
                                                        ?>

                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    XL
                                                </td>
                                                <td>
                                                    <select name="xl" id="bca" value="<?php echo $bca_fetch['xl']; ?>">
                                                        <?php
                                                        if($bca_fetch['xl'] == 'online'){
                                                            echo "<option value='online' selected>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";

                                                        }elseif($bca_fetch['xl'] == 'offline'){
                                                            echo "<option value='offline' selected>Offline</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";
                                                        }else{
                                                            echo "<option value='gangguan' selected>Gangguan</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                        }
                                                        
                                                        ?>

                                                    </select>
                                                </td>
                                            </tr>
                                                                                      <tr>
                                                <td>
                                                    Dana
                                                </td>
                                                <td>
                                                    <select name="dana" id="bca" value="<?php echo $bca_fetch['dana']; ?>">
                                                        <?php
                                                        if($bca_fetch['dana'] == 'online'){
                                                            echo "<option value='online' selected>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";

                                                        }elseif($bca_fetch['dana'] == 'offline'){
                                                            echo "<option value='offline' selected>Offline</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='gangguan'>Gangguan</option>";
                                                        }else{
                                                            echo "<option value='gangguan' selected>Gangguan</option>";
                                                            echo "<option value='online'>Online</option>";
                                                            echo "<option value='offline'>Offline</option>";
                                                        }
                                                        
                                                        ?>

                                                    </select>
                                                </td>
                                            </tr>


                                            <tr>
                                                <td class="btn-submit">
                                                    <button type="submit" name="submit" class="btn btn-warning submit"> Submit </button>
                                                </td>
                                                <td>
                                                    <button type="reset" name="submit" class="btn btn-danger submit"> Reset </button>
                                                </td>
                                                <td></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </fieldset>
                                </form>
                            </div>
                            <!-- <div class="d-block text-center card-footer">
                                <button class="mr-2 btn-icon btn-icon-only btn btn-outline-danger"><i class="pe-7s-trash btn-icon-wrapper"> </i></button>
                                <button class="btn-wide btn btn-success">Save</button>
                            </div> -->
                        </div>
                    </div>
                </div>

                <div class="app-wrapper-footer">
                    <div class="app-footer">
                        <div class="app-footer__inner">
                                <span>
                                    <a href="javascript:void(0);" class="nav-link">
                                        © All Rights Reserved
                                    </a>
                                </span>
                        </div>
                    </div>
                </div>
            </div>
            <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
        </div>
    </div>
    <script type="text/javascript" src="https://demo.dashboardpack.com/architectui-html-free/assets/scripts/main.js"></script></body>
</html>
