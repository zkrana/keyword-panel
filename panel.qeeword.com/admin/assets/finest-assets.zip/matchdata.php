<?php
include ("config.php");


if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    $errors= array();

    $matchname = mysqli_real_escape_string($connect,trim($_POST['match-name']));
    $matchday = mysqli_real_escape_string($connect,trim($_POST['day']));
    $matchdate = mysqli_real_escape_string($connect,trim($_POST['date']));
    $matchtime = mysqli_real_escape_string($connect,trim($_POST['time']));
    $stadiumname = mysqli_real_escape_string($connect,trim($_POST['stadium-name']));
    $matchteama = mysqli_real_escape_string($connect,trim($_POST['hometeam']));
    $matchteamb = mysqli_real_escape_string($connect,trim($_POST['awayteam']));

    if(!empty($matchname) && !empty($matchday) && !empty($matchdate) 
    && !empty($matchtime)  && !empty($stadiumname) && !empty($matchteama)
     && !empty($matchteamb)){
        
        // Get image name
        $imageA = $_FILES['hometeampic']['name'];
        $tmp_name = $_FILES['hometeampic']['tmp_name'];
        $imageB = $_FILES['awayteampic']['name'];
        $tmps_name = $_FILES['awayteampic']['tmp_name'];
        $file_size = $_FILES['hometeampic']['size'];
        $file_size2 = $_FILES['awayteampic']['size'];
  
        // image file directory
        $target = "img/uploads/".basename($imageA);
        $targetfold = "img/uploads/".basename($imageB);

    // Attempt insert query execution
        $sql = "INSERT INTO match_data (`match_name`, `match_day`, `match_date`, `match_time`, `match_stadium`, `homet_photo`, `awayt_photo`, `team_a`, `team_b`) 
        
        VALUES ('$matchname', '$matchday', '$matchdate','$matchtime','$stadiumname','$imageA','$imageB','$matchteama','$matchteamb')";
        
        if(mysqli_query($connect, $sql)){
            $file_ext=strtolower(end(explode('.',$_FILES['hometeampic']['name'])));
            $file_ext2=strtolower(end(explode('.',$_FILES['awayteampic']['name'])));
      
            $extensions= array("jpeg","jpg","png");
            
            if(in_array($file_ext,$extensions)=== false && in_array($file_ext2,$extensions)=== false){
                $errors[]="extension not allowed, please choose a JPEG or PNG file.";
            }
            
            if($file_size > 2097152 && $file_size2 > 2097152){
                $errors[]='File size must be excately 2 MB';
            }
            
            if(empty($errors)){
                if(move_uploaded_file($_FILES['hometeampic']['tmp_name'], $target) && move_uploaded_file($_FILES['awayteampic']['tmp_name'], $targetfold)) {
                
                }
                header("Location: bigmatch.php?error=$errors()");
            }else{
                print_r($errors);
            }
           
        } else{
            echo "ERROR: Could not able to execute $sql. " . mysqli_error($connect);
        }
    }
}





?>