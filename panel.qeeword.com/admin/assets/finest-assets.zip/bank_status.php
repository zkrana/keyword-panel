<?php
include ("config.php");
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $bank_bca = mysqli_real_escape_string($connect, trim($_POST['bca']));
    $bank_bna = mysqli_real_escape_string($connect, trim($_POST['bni']));
    $bank_bri = mysqli_real_escape_string($connect, trim($_POST['bri']));
    $bank_mandiri = mysqli_real_escape_string($connect, trim($_POST['mandiri']));
    $bank_danamon = mysqli_real_escape_string($connect, trim($_POST['danamon']));
    $bank_cimb = mysqli_real_escape_string($connect, trim($_POST['cimb']));
    $bank_gopay = mysqli_real_escape_string($connect, trim($_POST['gopay']));
    $bank_linkaja = mysqli_real_escape_string($connect, trim($_POST['linkaja']));
    $bank_ovo = mysqli_real_escape_string($connect, trim($_POST['ovo']));
    $bank_telkomsel = mysqli_real_escape_string($connect, trim($_POST['telkomsel']));
    $bank_xl = mysqli_real_escape_string($connect, trim($_POST['xl']));
    $bank_dana = mysqli_real_escape_string($connect, trim($_POST['dana']));
    
    if(!empty($bank_bca) && !empty($bank_bna) && !empty($bank_bri) && !empty($bank_mandiri) && !empty($bank_danamon) && !empty($bank_cimb)){
        
         $b_status = "INSERT INTO bank_status (`bca`,`bni`,`bri`,`mandiri`,`danamon`,`cimb`,`gopay`,`linkaja`,`ovo`,`telkomsel`,`xl`,`dana`) VALUES ('$bank_bca','$bank_bna','$bank_bri','$bank_mandiri','$bank_danamon','$bank_cimb','$bank_gopay','$bank_linkaja','$bank_ovo','$bank_telkomsel','$bank_xl','$bank_dana')";

        $sql_inst = mysqli_query($connect, $b_status);
        if($sql_inst){
            header("Location: managebank.php");
        }else{
            echo "Data Insert Failed.";
        }
    }
}



?>