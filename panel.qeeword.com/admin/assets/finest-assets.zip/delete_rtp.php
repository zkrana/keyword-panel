<?php
include("config.php");
if(isset($_GET['id'])){
    $del_id= $_GET['id'];
    
    $data = "SELECT * FROM game_item WHERE id = '$del_id'";
    $query = mysqli_query($connect, $data);
    $after = mysqli_fetch_assoc($query);
    
    $del_sql="DELETE FROM game_item WHERE id=$del_id"; 
    $query = mysqli_query($connect,$del_sql);
    if($query){
        unlink('./img/uploads/game_photo/'.$after['game_image']);
        header("Location: rtp_all_game.php");
        die();
    }
}
?>