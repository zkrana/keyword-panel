<?php

$host_source='localhost';
$host_user='root';
$user_passcode='';
$db_name='parlayadmin';

$connect = mysqli_connect($host_source,$host_user,$user_passcode,$db_name);

// Check connection
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
  }
?>