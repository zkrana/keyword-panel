<?php

$host_source='localhost';
$host_user='root';
$user_passcode='';
$db_name='parlayadmin';
$connect = mysqli_connect($host_source,$host_user,$user_passcode,$db_name);

// Check connection
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
  }



if(isset($_FILES['user_files'])){
    //$errors = array();

    $file_name = $_FILES['user_files']['name'];
    $file_size = $_FILES['user_files']['size'];
    $file_tmp = $_FILES['user_files']['tmp_name'];
    $file_type = $_FILES['user_files']['type'];
    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);

    $extensions = array("jpeg","jpg","png");

    if(in_array($file_ext,$extensions) === false)
    {
        echo "This extension file not allowed, Please choose a JPG or PNG file.";
        die();
    }

    if($file_size > 2097152){
        echo "File size must be 2mb or lower.";
        die();
    }
    $target = "img/uploads/user_photo/".basename($file_name);

    if(empty($errors) == true){
        if(move_uploaded_file($_FILES['user_files']['tmp_name'],$target)){
            
        }
    }else{
        //print_r($errors);
        die();
    }


    $user_first_name = mysqli_real_escape_string($connect,$_POST['first_name']);
    $user_last_name = mysqli_real_escape_string($connect,$_POST['last_name']);
    $username = mysqli_real_escape_string($connect,$_POST['username']);
    $user_email = mysqli_real_escape_string($connect,$_POST['email']);
    $user_passe = stripslashes($_POST['passcode']);
    $user_passes = mysqli_real_escape_string($connect,$user_passe);
    $user_pass = md5($user_passes);
    $user_role = mysqli_real_escape_string($connect,$_POST['user_role']);
    $user_status = mysqli_real_escape_string($connect,$_POST['userstatus']);

    if(!empty($user_first_name) && !empty($user_last_name) && !empty($username) && !empty($user_email)
    && !empty($user_passes)  && !empty($user_role)
     && !empty($user_status)) {

        if (!preg_match("/^[a-zA-Z0-9-' ]*$/", $username)) {
            echo "Only text without spache are allowed. Try again.";
            die();
        }

        if (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
            echo "Invalid email format";
            die();
        }

        // Attempt insert query execution
        $sql_u = "select * from user_table where username='{$username}'";
        $sql_e = "SELECT * FROM user_table WHERE user_email='$user_email'";
        $res_u = mysqli_query($connect, $sql_u);
        $res_e = mysqli_query($connect, $sql_e);

        if (mysqli_num_rows($res_u) > 0) {
            echo "Sorry... username already taken";
        } else if (mysqli_num_rows($res_e) > 0) {
            echo "Sorry... email already taken";
        } else {
            $sql = "INSERT INTO user_table (first_name,last_name,username,user_email,password,user_role,photo,status) 
            VALUES ('$user_first_name', '$user_last_name', '$username', '$user_email', '$user_pass', '$user_role', '$file_name', '$user_status')";

            if (mysqli_query($connect, $sql)) {
                header("Location: adduser.php");

            } else {
                echo "ERROR: Could not able to execute .$sql. " . mysqli_error($connect);
            }
        }

    }
}
?>