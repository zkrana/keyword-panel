<?php
   include ("config.php");
   session_start();
   if(!isset($_SESSION['id'])){
        header("Location: ../index.php");
        exit();
    }
    // if(isset($_SESSION['status'])=='inactive'){
    //      header("Location: ../index.php");
    //     exit();
    // }
    
   if(isset($_SESSION['id'])){
   $user_check = $_SESSION['id'];
   
   $ses_sql = mysqli_query($connect,"select id, username, user_role, user_email, photo from user_table where id = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   $id = $row['id'];
   $login_session = $row['username'];
   $login_role = $row['user_role'];
   $user_photo = $row['photo'];
	$login_session_duration = 1000; 
	$current_time = time(); 
	if(isset($_SESSION['loggedin_time']) and isset($_SESSION["id"])){ 
	    
		if(((time() - $_SESSION['loggedin_time']) > $login_session_duration)){ 
            session_unset($_SESSION["id"]);
            session_destroy();
            session_start();
            header("Location: ../index.php"); 
		} 
	}
    
}
?>