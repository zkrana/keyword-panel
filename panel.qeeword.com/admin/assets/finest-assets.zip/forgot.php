<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parlay 4D Admin Login</title>
    <link rel="stylesheet" type="text/css" href="../css/login.css">
</head>
<body>

    <div class="container">
        <div class="card"></div>
            <div class="card">
                <h1 class="title">Forgot Password</h1>
                <form action="getpass.php" method="POST">
                    <div class="input-container">
                        <input type="text" id="#{label}" name="forgetpass" required="required"/>
                        <label for="#{label}">Your Email</label>
                        <div class="bar"></div>
                    </div>
                    <div class="button-container">
                        <button type="submit"><span>Get Password</span></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>
</html>