<?php

$host_source='localhost';
$host_user='root';
$user_passcode='';
$db_name='parlayadmin';
$connect = mysqli_connect($host_source,$host_user,$user_passcode,$db_name);

// Check connection
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
  }

    if(isset($_REQUEST['submit'])){
        $liga_name = $_REQUEST['liga_name'];
        $team_a = $_REQUEST['team_a'];
        $team_b = $_REQUEST['team_b'];
        $match_date = $_REQUEST['date'];
        $match_time = $_REQUEST['time'];
        $update_id = $_REQUEST['updating_hidden_value'];
        echo $update_id;

        foreach($team_a as $key => $value)
          {
            $team_1 = $value;
            $liga_n = $liga_name[$key];
            $team_2 = $team_b[$key];
            $ins_date = $match_date[$key];
            $ins_time = $match_time[$key];
            $up_match_data = "UPDATE upcoming_match SET liga_name='$liga_n', team1='$team_1',team2='$team_2',date='$ins_date',time='$ins_time' WHERE id = $update_id";
            if(mysqli_query($connect,$up_match_data)){
                header("Location: upcomingmatch.php");
            }
        }

    }

?>