<?php

$host_source='localhost';
$host_user='root';
$user_passcode='';
$db_name='parley_match_data';

// $host_source='localhost';
// $host_user='root';
// $user_passcode='';
// $db_name='testdata';


$connect = mysqli_connect($host_source,$host_user,$user_passcode,$db_name);

// Check connection
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}

if(isset($_POST['addGame']))
{

    $percent = mysqli_real_escape_string($connect, $_POST['win_rate']);
    $gameName = mysqli_real_escape_string($connect, $_POST['game_name']);
    $file_name = $_FILES['game_files']['name'];
    $tmp_name = $_FILES['game_files']['tmp_name'];


    // get the image extension
    $extension = substr($file_name,strlen($file_name)-4,strlen($file_name));
    // allowed extensions
    $allowed_extensions = array(".jpg","jpeg",".png",".gif",".webp");
    // Validation for allowed extensions .in_array() function searches an array for a specific value.
    if(!in_array($extension,$allowed_extensions))
    {
        echo "<script>alert('Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
    }
    else

    {

        // Code for move image into directory
        move_uploaded_file($tmp_name,"../assets/img/uploads/game_photo/".basename($file_name));


            $sql = "INSERT INTO game_item (`game_image`,`game_name`,`percent`) 
    VALUES ('$file_name','$gameName','$percent')";

            if (mysqli_query($connect, $sql)) {
                echo "<script>alert('You have successfully inserted the data');</script>";
                echo "<script type='text/javascript'> document.location ='../assets/addgame.php'; </script>";

            } else {
                echo "<script>alert('Something Went Wrong. Please try again');</script>";
        }
     }
}


?>