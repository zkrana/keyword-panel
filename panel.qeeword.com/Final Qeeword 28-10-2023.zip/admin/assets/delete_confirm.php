<?php
include 'session.php';

// Establish a database connection (Replace with your database credentials)
$host_source='localhost';
$host_user='qeeword_kUsQee';
$user_passcode='VB[g_d}{PNJ_';
$db_name='qeeword_keyPQ';

$connect = mysqli_connect($host_source, $host_user, $user_passcode, $db_name);

// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id = mysqli_real_escape_string($connect, $_GET['id']);
    
    // Create a query to retrieve the keyword name based on the provided ID
    $getKeywordNameQuery = "SELECT keyword_name FROM keywords WHERE id = $id";
    $result = mysqli_query($connect, $getKeywordNameQuery);

    if ($row = mysqli_fetch_assoc($result)) {
        $keyword_name = $row['keyword_name'];
    } else {
        // Handle the case where the keyword doesn't exist
        $_SESSION['error_message'] = "Keyword not found.";
        header("Location: dashboard.php"); // Redirect back to the dashboard
        exit;
    }

    // Create JavaScript code to display a confirmation dialog with the keyword name
    echo "<script>";
    echo "var confirmDelete = confirm('Are you sure you want to delete the keyword: $keyword_name?');";
    echo "if (confirmDelete) {";
    echo "   window.location.href = 'delete_keyword.php?id=$id';"; // Redirect to the delete script if confirmed
    echo "} else {";
    echo "   window.location.href = 'dashboard.php';"; // Redirect back to the dashboard if canceled
    echo "}";
    echo "</script>";
}
?>
