<?php

error_reporting(error_reporting() & ~E_NOTICE);

include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $myusername = mysqli_real_escape_string($connect, $_POST['username']);
    $password = stripslashes($_POST['password']);
    $myuserpass = mysqli_real_escape_string($connect, $_POST['passcode']);
    $passcode = md5($myuserpass);

    $stmt = $connect->prepare("SELECT id, username, user_email, password, status FROM user_table WHERE (username = ? OR user_email = ?) AND password = ?");
    $stmt->bind_param("sss", $myusername, $myusername, $passcode);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($user_id, $user, $mail, $pass, $user_status);
        $stmt->fetch();

        if ($myusername == $user || $myusername == $mail) {
            if ($passcode == $pass) {
                if ($user_status == 'active') {
                    session_start();
                    $_SESSION['id'] = $user_id;
                    $_SESSION['status'] = $user_status;
                    $_SESSION['loggedin_time'] = time();
                    header("location: dashboard.php");
                    exit;
                } else {
                    $errors = "Your account is now inactive by admin. Please contact the admin.";
                    header("Location: ../../index.php?error=" . urlencode($errors));
                }
            } else {
                $errors = "Password not matched.";
                header("Location: ../../index.php?error=" . urlencode($errors));
            }
        } else {
            $errors = "Username Not Matched.";
            header("Location: ../../index.php?error=" . urlencode($errors));
        }
    } else {
        // Username, email, or password not matched
        header("Location: ../../index.php?error='Login failed. Please check your credentials.'");
    }

    $stmt->close();
}
?>
